package skill

import (
	"os"
	"strings"
	"testing"
)

// The skill states the governance rules the server already enforces.
//
// Stating them is not redundancy. A rule the client understands produces a good
// refusal with a reason; a rule only the server knows produces a 403 the agent
// retries. But a copy is a copy, and a copy drifts — so this checks that every
// rule AGENTS.md carries is still present in the skill, and fails when AGENTS.md
// changes without the skill following.
//
// It checks against THIS repository's AGENTS.md, not company-workgraph's, for a
// deliberately boring reason: a test that reads a path in another repository
// passes vacuously the moment that repository is not checked out beside this
// one, and a vacuous governance test is worse than none.

const (
	skillPath  = "../../skills/workgraph/SKILL.md"
	agentsPath = "../../AGENTS.md"
)

// read returns the file lower-cased with runs of whitespace collapsed.
//
// Collapsing matters: Markdown wraps, so a phrase this test looks for can be
// split across a newline by nothing more than reflowing a paragraph. A test that
// fails when prose is rewrapped is a test somebody eventually deletes.
func read(t *testing.T, path string) string {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("reading %s: %v", path, err)
	}
	return strings.Join(strings.Fields(strings.ToLower(string(b))), " ")
}

// Each rule: what AGENTS.md must still say, and what the skill must still say
// about it. If AGENTS.md drops a rule, the first half fails and somebody has to
// decide deliberately. If the skill drops one, the second half fails.
func TestSkillCarriesEveryGovernanceRule(t *testing.T) {
	skill := read(t, skillPath)
	agents := read(t, agentsPath)

	for _, rule := range []struct {
		name         string
		inAgents     []string
		inSkill      []string
		whyItMatters string
	}{
		{
			name:         "evidence closes a bead",
			inAgents:     []string{"evidence"},
			inSkill:      []string{"evidence closes a bead"},
			whyItMatters: "an agent that closes on its own assertion produces a graph nobody can trust",
		},
		{
			name:         "extraction is a candidate, not a record",
			inAgents:     []string{"candidate"},
			inSkill:      []string{"candidate", "knowledge/"},
			whyItMatters: "writing model output into knowledge/ is a governance violation even when true",
		},
		{
			name:         "source material is untrusted",
			inAgents:     []string{"untrusted", "prompt-injection"},
			inSkill:      []string{"untrusted", "prompt-injection"},
			whyItMatters: "issue and PR bodies reach the agent through this API and are attacker-controlled",
		},
		{
			name:         "classification is never widened",
			inAgents:     []string{"classification"},
			inSkill:      []string{"classification", "restricted"},
			whyItMatters: "this is how restricted client material becomes publishable by accident",
		},
		{
			name:         "protected actions are escalated",
			inAgents:     []string{"protected action"},
			inSkill:      []string{"protected action", "approval"},
			whyItMatters: "a token that could decide an approval would defeat the approval model entirely",
		},
	} {
		for _, want := range rule.inAgents {
			if !strings.Contains(agents, want) {
				t.Errorf("AGENTS.md no longer mentions %q (rule: %s).\n"+
					"If the rule was dropped deliberately, drop it from the skill too. %s",
					want, rule.name, rule.whyItMatters)
			}
		}
		for _, want := range rule.inSkill {
			if !strings.Contains(skill, want) {
				t.Errorf("the skill no longer mentions %q (rule: %s).\n"+
					"The server still enforces it, so an agent that does not know it will retry a 403. %s",
					want, rule.name, rule.whyItMatters)
			}
		}
	}
}

// The skill must not teach an agent to do the one thing it cannot do.
func TestSkillTellsTheAgentNotToMintTokens(t *testing.T) {
	skill := read(t, skillPath)
	for _, want := range []string{"wg login", "do not try to mint"} {
		if !strings.Contains(skill, want) {
			t.Errorf("the skill does not say %q; an agent hitting exit 3 will try to mint a token "+
				"and fail in a way it cannot diagnose", want)
		}
	}
}

// Exit codes are the interface an agent branches on. If the skill documents them
// wrongly, an agent retries what it must not.
func TestSkillDocumentsTheExitCodesThatMatter(t *testing.T) {
	skill := read(t, skillPath)
	for _, want := range []string{
		"unauthenticated", "forbidden", "refused by policy", "rate limited", "conflict",
	} {
		if !strings.Contains(skill, want) {
			t.Errorf("the skill does not document the %q exit code", want)
		}
	}
	if !strings.Contains(skill, "do not retry") {
		t.Error("the skill does not tell the agent when NOT to retry, which is the failure " +
			"a 5 retried forever produces")
	}
}

// The chief-of-staff endpoint answers four questions and refuses a fifth. A
// skill that does not say so produces an agent that guesses and collects 400s.
func TestSkillSaysToListTheQuestionsRatherThanGuess(t *testing.T) {
	skill := read(t, skillPath)
	if !strings.Contains(skill, "four questions") {
		t.Error("the skill does not say /v1/ask answers a fixed set; an agent will invent a fifth")
	}
	if !strings.Contains(skill, "wg ask") {
		t.Error("the skill does not show how to list the answerable questions")
	}
}

// Dispatch spends money. An agent that does not know that will spend it.
func TestSkillWarnsThatDispatchSpendsMoney(t *testing.T) {
	skill := read(t, skillPath)
	if !strings.Contains(skill, "spends money") {
		t.Error("the skill does not warn that dispatch spends money")
	}
}

// The Codex variant must carry the same content as the skill.
//
// Two files saying almost the same thing is exactly how one of them becomes
// wrong, and the one that goes wrong is always the one fewer people read. This
// asserts the body matches so the pair cannot drift into disagreeing about what
// an agent may do.
func TestCodexVariantMatchesTheSkill(t *testing.T) {
	skill := read(t, skillPath)
	codex := read(t, "../../skills/workgraph/AGENTS.md")

	// Everything from the first section heading onward must be identical.
	const anchor = "## before anything else"
	si := strings.Index(skill, anchor)
	ci := strings.Index(codex, anchor)
	if si < 0 || ci < 0 {
		t.Fatal("one of the two files no longer has the anchor section; they cannot be compared")
	}
	if skill[si:] != codex[ci:] {
		t.Error("skills/workgraph/AGENTS.md has drifted from SKILL.md.\n" +
			"Edit the skill and regenerate the variant; two files saying almost the same thing " +
			"is how one of them becomes wrong.")
	}
}
