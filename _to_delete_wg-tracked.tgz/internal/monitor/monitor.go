// Package monitor decides whether the platform is in trouble and who to tell.
//
// The threat model names detection as the weakest link, and it named it from
// experience: a database password was silently reset, reconciliation failed SASL
// authentication on every attempt, the backlog stopped draining, and nobody
// noticed until somebody asked why a view looked stale. Every individual piece
// was working as designed. What was missing was anything whose job was to look.
//
// The design follows the deterministic witness (ADR-0019) deliberately. The
// decision of whether something is wrong is a pure function of observed numbers,
// separated from both the gathering and the reporting, so the interesting cases
// — the ones that are painful to arrange against a live system — are ordinary
// table-driven tests. Collection needs a database, a filesystem and a socket.
// Judgement needs none of them.
//
// What this package deliberately does NOT do is decide anything by asking a
// model. An alerting path that costs money per evaluation is one somebody turns
// off, and a non-deterministic alerting path cannot be tested at all.
package monitor

import (
	"time"
)

// Class is one kind of trouble: its inbox rule, how loudly it ranks against
// everything else competing for an operator's attention, and the runbook that
// says what to do about it.
//
// The runbook is part of the class rather than something added at the reporting
// layer, because an alert without one is a notification that something is wrong
// and no help whatsoever at 3am. The acceptance criterion for this work package
// is that the alert reaches the operator WITH a runbook link, so the link is
// structural: there is no way to declare a class without one, and a test asserts
// every runbook file actually exists.
type Class struct {
	// Name is the short identifier used in logs, metrics and the acceptance
	// test.
	Name string
	// Rule is the inbox rule. Operators filter and unsubscribe by rule, so
	// each class is its own rule even where two classes share a cause.
	Rule string
	// Runbook is the repository-relative path to the procedure.
	Runbook string
	// Score orders this against every other inbox rule on the same 0..1 scale.
	Score float64
}

// DedupeKey is the identity of an ongoing problem.
//
// It is deliberately STABLE for the lifetime of a problem rather than including
// a timestamp. system_raise_attention upserts on (user_id, dedupe_key) for items
// that are open or snoozed: a stable key means one inbox item per operator that
// is refreshed with current detail on every cycle, and a snooze the operator set
// survives the machine noticing the problem again. A key containing the time
// would instead produce a new item every cycle, which is how an alerting system
// teaches people to ignore it.
func (c Class) DedupeKey() string { return "monitor:" + c.Name }

// The classes this package covers. The first five are the ones WP-I1 required —
// API, webhook, agent stall, disk and backup — and the two after them cover
// failures found by running the platform rather than by planning it.
var (
	// ClassAPI is the control API being unable to serve traffic. Highest score
	// because everything else the platform does is reached through it.
	ClassAPI = Class{
		Name:    "api",
		Rule:    "platform_api_unavailable",
		Runbook: "docs/runbooks/api-unavailable.md",
		Score:   0.98,
	}

	// ClassWebhook is inbound GitHub deliveries arriving and not being
	// processed. This is the shape of the failure that actually happened: the
	// endpoint kept accepting deliveries and returning 200 while nothing
	// downstream consumed them, so from GitHub's side everything looked fine.
	ClassWebhook = Class{
		Name:    "webhook",
		Rule:    "platform_webhook_backlog",
		Runbook: "docs/runbooks/webhook-backlog.md",
		Score:   0.9,
	}

	// ClassAgentStall is the WITNESS having gone quiet, not an agent having
	// stalled.
	//
	// A stalled agent is already reported: the deterministic witness decides it
	// and raises agent_work_at_risk or agent_silent through the same inbox. This
	// class covers the failure that path cannot report, because it is the path —
	// if the witness dies, every future stall goes unnoticed and the inbox stays
	// reassuringly empty. Silence from a component whose job is to report
	// trouble is indistinguishable from good news, which is why it needs its own
	// alert rather than being inferred from the absence of one.
	ClassAgentStall = Class{
		Name:    "agent_stall",
		Rule:    "platform_agent_health_silent",
		Runbook: "docs/runbooks/agent-health-silent.md",
		Score:   0.85,
	}

	// ClassDisk is a filesystem approaching full. It ranks below the others
	// because it is a warning about the future rather than a present outage —
	// but only just, because PostgreSQL on a full disk stops accepting writes
	// and the recovery is materially worse than the prevention.
	ClassDisk = Class{
		Name:    "disk",
		Rule:    "platform_disk_pressure",
		Runbook: "docs/runbooks/disk-pressure.md",
		Score:   0.8,
	}

	// ClassBackup is a backup stream that is stale or has never run. Scored
	// like disk: nothing is broken right now, and everything is broken later.
	ClassBackup = Class{
		Name:    "backup",
		Rule:    "platform_backup_stale",
		Runbook: "docs/runbooks/backup-stale.md",
		Score:   0.8,
	}

	// ClassService is a unit that is supposed to be running and is not.
	//
	// Scored just below the API because it covers the API, and because of the
	// failure that prompted it (wg-95y). Event freshness depends on
	// workgraph-worker, which projects deliveries on a five-second poll. If the
	// worker dies, the fifteen-minute reconciliation timer still drains the
	// backlog — so deliveries keep being processed, nothing looks broken, and
	// freshness silently returns to its old p50 of 459s against a 60s target.
	// The webhook check cannot see it, because the backlog never gets old
	// enough to trip it.
	//
	// Degraded rather than broken, and invisible because the fallback is good
	// enough to hide it. That is exactly the shape WP-I1 exists to catch, and
	// the only honest way to catch it is to ask whether the unit is running
	// rather than to infer it from a downstream symptom.
	ClassService = Class{
		Name:    "service",
		Rule:    "platform_service_down",
		Runbook: "docs/runbooks/service-down.md",
		Score:   0.95,
	}

	// ClassCostImport is spend no longer being imported (wg-7jz).
	//
	// Quiet by construction: a stopped importer leaves usage_records simply not
	// growing, which looks exactly like a quiet week. Everything built on top
	// then degrades silently — a budget check refuses on stale data, and a cost
	// report is confidently wrong.
	//
	// Scored below disk and backup. Nothing is failing for a user, and the
	// budget check already refuses rather than guessing when the data is stale,
	// so this is the alert that explains why that is happening.
	ClassCostImport = Class{
		Name:    "cost_import",
		Rule:    "platform_cost_import_stale",
		Runbook: "docs/runbooks/cost-import-stale.md",
		Score:   0.7,
	}

	// A Google Workspace subscription that has expired, been suspended, or
	// failed to renew.
	//
	// This is the failure the whole WP-H1 timer exists to prevent, and it is
	// invisible without a check: Google expires a subscription within days, and
	// when one lapses the source simply stops delivering. Nothing errors,
	// nothing is slow, no request fails. Sources go quiet one at a time over the
	// following week and the first sign is somebody asking why a meeting never
	// turned into work.
	//
	// Scored above cost import and below backup. No user is blocked, but every
	// hour it goes unnoticed is an hour of meetings and file changes that will
	// never be ingested — and unlike a backlog, the missed events do not
	// accumulate somewhere waiting to be processed. They are gone.
	ClassWorkspaceSources = Class{
		Name:    "workspace_sources",
		Rule:    "platform_workspace_subscription_lapsed",
		Runbook: "docs/runbooks/workspace-subscriptions.md",
		Score:   0.75,
	}
)

// Classes is every class, in the order a report prints them.
var Classes = []Class{
	ClassAPI, ClassService, ClassWebhook, ClassAgentStall,
	ClassDisk, ClassBackup, ClassCostImport, ClassWorkspaceSources,
}

// Finding is the verdict on one class.
//
// A finding is produced whether or not anything is wrong, because "checked and
// healthy" and "not checked" are different states and collapsing them is how a
// check silently stops running. Failing distinguishes them; Observed carries the
// numbers the verdict was reached from, so the inbox item explains itself rather
// than asserting a conclusion.
type Finding struct {
	Class    Class
	Failing  bool
	Summary  string
	Observed map[string]any
}

// Thresholds are the numbers that separate healthy from failing.
//
// They are configuration rather than constants because the right value differs
// between staging and production, and because a threshold that cannot be changed
// without a release is one that gets worked around instead.
type Thresholds struct {
	// WebhookBacklogAge is how long a delivery may sit unprocessed.
	//
	// It MUST be comfortably longer than the reconciliation period, because a
	// delivery that arrives just after a pass waits the full period by design.
	// Reconciliation runs every 15 minutes, and staging was observed with 20
	// deliveries whose oldest was 9 minutes — entirely healthy, and a 15-minute
	// threshold would have alerted on it within one cycle. An alerting system
	// that fires during correct operation is one people mute in week one.
	WebhookBacklogAge time.Duration
	// AgentHealthSilence is how long the control plane may receive no
	// agent-health report before the witness is presumed dead. Comfortably
	// more than the witness's own sweep interval, so a single missed pass is
	// not an alert.
	AgentHealthSilence time.Duration
	// DiskUsedPercent is the fullest a filesystem may get.
	DiskUsedPercent float64
	// CostImportMaxAge is how long since the least recent gateway import before
	// the importer is presumed stopped.
	//
	// Measured from the last successful RUN, not from the newest usage record.
	// A gateway nobody has used for a week has a newest record a week old
	// however punctually the importer ran — the same distinction 0033 had to
	// make for the budget check, which was refusing every dispatch on a quiet
	// environment.
	CostImportMaxAge time.Duration
	// SubscriptionRenewalGrace is how close to expiry an active Google
	// Workspace subscription may get before the renewer is presumed stopped.
	//
	// Measured against the expiry, not against the last renewal: a subscription
	// Google gives seven days does not need renewing daily, so "last renewed
	// three days ago" is healthy. What is never healthy is an expiry closer than
	// the reconciler's own renewal window, because that means a pass which
	// should have renewed it either did not run or did not succeed.
	//
	// Must be SHORTER than workspace.DefaultPolicy.RenewBefore (24h), or the
	// alert fires during correct operation — every subscription passes through
	// the renewal window on its way to being renewed. Twelve hours leaves the
	// reconciler twelve hourly passes to do its job before anybody is told.
	SubscriptionRenewalGrace time.Duration
}

// DefaultThresholds are the values the deployment uses unless overridden.
func DefaultThresholds() Thresholds {
	return Thresholds{
		// Three reconciliation periods. One missed pass is normal — a slow
		// GitHub call, a restart during deployment. Three consecutive misses
		// means the consumer is not running, which is the condition worth
		// waking somebody for.
		WebhookBacklogAge:  45 * time.Minute,
		AgentHealthSilence: 30 * time.Minute,
		DiskUsedPercent:    85,
		// Three hourly import periods, matching the reasoning above: one missed
		// run is normal, three consecutive misses means it is not running.
		CostImportMaxAge: 3 * time.Hour,
		// Half the reconciler's 24-hour renewal window. Twelve hourly passes to
		// renew a subscription before anybody is told, and still twelve hours of
		// warning before it actually lapses.
		SubscriptionRenewalGrace: 12 * time.Hour,
	}
}
